# Nolan Cinematic Prompts 安装说明

这是一个可直接安装到 Codex 的 Skill，用于生成和校准克制、写实、大银幕质感的图片、视频及分镜提示词。

## 安装

1. 解压安装包。
2. 将整个 `nolan-cinematic-prompts` 文件夹复制到 Codex 的 Skills 目录。

macOS / Linux 默认目录：

```text
~/.codex/skills/
```

Windows 默认目录：

```text
%USERPROFILE%\.codex\skills\
```

安装完成后的目录应为：

```text
~/.codex/skills/nolan-cinematic-prompts/SKILL.md
```

如果设置过 `CODEX_HOME`，请改用 `$CODEX_HOME/skills/`。已有旧版本时，先备份旧文件夹，再用本安装包中的同名文件夹完整替换。安装后重新启动 Codex，或新建一个任务，让 Codex 重新加载 Skills。

## 使用

在 Codex 中直接调用：

```text
$nolan-cinematic-prompts
```

示例：

```text
$nolan-cinematic-prompts 把“一个人独自站在退潮后的海滩上”改写成横向 16:9 的电影图片提示词。
```

```text
$nolan-cinematic-prompts 把这张图片做成 8 秒一镜到底的图生视频提示词，保持人物与构图不变。
```

```text
$nolan-cinematic-prompts 检查这张生成图为什么像 AI 概念图，并给出修正后的完整提示词。
```

## 包含内容

```text
nolan-cinematic-prompts/
├── SKILL.md
├── agents/
│   └── openai.yaml
└── references/
    ├── aesthetic-language.md
    ├── color-signature.md
    ├── examples.md
    └── reference-baseline.md
```

本 Skill 不需要安装 Python 包、MCP 服务或其他外部依赖。
